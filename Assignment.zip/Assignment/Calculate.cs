﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    abstract class Calculate
    {
        public abstract int Area();
        public abstract int Perimeter();
    }
}
